console.log("BucketListsController");

var mongoose = require("mongoose"),
    path = require("path"),
    bp = require("body-parser"),
    User = mongoose.model("Users"),
    BucketList = mongoose.model("BucketLists");

function handleError(err){
  console.log(err);
  return err;
}


function BucketListsController(){

  this.index = function(req, res){
    console.log("Index");
    //console.log(Day.find({}));
    BucketList.find({})
    .populate("_user")
    .populate("_userB")
    .exec(function(err, bucketLists){
      if(err) console.log("Errors!");
      //console.log(bucketLists);
      res.json(bucketLists);
    });
  };
  
  // This create method is used to create new bucketLists.
  this.create = function(req, res){
    console.log("Create");
    console.log("Dir req");
    console.dir(req.body);

    // find the user document
    User.findById(req.body._user._id, function(err, user){
      if(err){
        console.log(err);
        res.json(err);
      }

      // Search for bucketLists with the same date as the bucketList being
      // created.
      BucketList.find({date: req.body.date}, function(err, bucketLists){
        if(err){
          //console.log(err);
          return res.status(500).json(err.data);
        }
        // If there are already three bucketLists for the day, return error
        //console.log(bucketLists);



        // Get the current timezone offset.
        //var offset = new Date().getTimezoneOffset();
        // Add the offset into the req.body object
        //req.body.timezoneOffset = offset;
        //console.log(req.body.timezoneOffset);
        //console.log(req.body);


        var date = new Date(req.body.date);
        console.log(date + " Date!!");
        req.body.date = date;
        console.log(req.body);
        console.log(req.body.date);



        //console.dir(Date.now());
        //console.log(Date.parse(req.body.date));
        
        // Time validation
        // Date.parse() converts the date into miliseconds since Jan 1, 1970
        // Date.now() provides the current date in miliseconds since Jan 1, 1970
        if(Date.parse(req.body.date) < Date.now()){
          return res.status(500).json(["BucketLists dates must be in the future."]);
        }



        // If there is space for the bucketList, instantiate the new
        // bucketList object.
        var bucketList = new BucketList(req.body);
        bucketList.save(function(err){
          //console.dir(bucketList.toObject());
          //console.dir(err);
          if(err){
            var keys = Object.keys(err.errors);
            //console.log(keys);
            var returnValue = [];

            for(var i = 0; i < keys.length; i++){
              returnValue[i] = err.errors[keys[i]].message;
            }
            //console.log(returnValue);
            //console.log("out!");
            return res.status(500).json(returnValue);
          }
          res.json(bucketList);
        });


      });
    });
  };

  this.update = function(req, res){
    console.log("Update");
    BucketList.find({_id:req.params.id}).update(req.params);
    res.json("BucketList updated");
  }

  this.delete = function(req, res){
    console.log("Delete");
    console.log(req.params.id);
    BucketList.find({_id:req.params.id}).remove().exec();
    // my code here...
    res.json("BucketList deleted");
  };
}


module.exports = new BucketListsController();
